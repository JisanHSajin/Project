<?php
header("Referrer-Policy: no-referrer");
header("X-Content-Type-Options: nosniff");

/* ================= CONFIG ================= */
$m3u_url = "https://jisanhsajin.neocities.org/LiveNetTV/JisanTV.m3u"; // 🔴 PUT YOUR M3U LINK HERE

/* ================= FETCH & PARSE M3U ================= */
$m3u = @file_get_contents($m3u_url);
if (!$m3u) {
    die("Failed to load M3U playlist");
}

$lines = explode("\n", $m3u);
$channels = [];

for ($i = 0; $i < count($lines); $i++) {
    if (strpos($lines[$i], '#EXTINF') !== false) {

        preg_match('/tvg-logo="([^"]*)"/', $lines[$i], $logo);
        preg_match('/,(.*)$/', $lines[$i], $name);

        $url = trim($lines[$i + 1] ?? '');

        if ($url) {
            $channels[] = [
                'name' => $name[1] ?? 'Unknown',
                'logo' => $logo[1] ?? 'https://via.placeholder.com/150',
                'url'  => $url
            ];
        }
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>Md Jisan Hossain Sajin</title>

<link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
<script src="https://cdn.jsdelivr.net/npm/hls.js@latest"></script>

<style>
:root{
    --neon:#00ffd5;
    --accent:#00aaff;
    --bg:#020b10;
}
body{
    background:
        radial-gradient(circle at 20% 10%, #0a3d3f, transparent 40%),
        radial-gradient(circle at 80% 0%, #003344, transparent 35%),
        var(--bg);
    color:#fff;
    font-family:"Segoe UI",system-ui;
    user-select:none;
    overflow-x:hidden;
    margin:0;
}

/* HEADER */
.site-header{
    background:var(--bg);
    padding:12px 20px;
    display:flex;
    align-items:center;
    justify-content:space-between;
    position:sticky;
    top:0;
    z-index:999;
    border-bottom:1px solid rgba(0,255,213,.2);
    flex-wrap:wrap;
}
.site-branding a{
    display:flex;
    align-items:center;
    gap:12px;
    text-decoration:none;
    color:var(--neon);
}
.site-branding img{
    width:50px;height:50px;border-radius:8px;
}
.header-links{
    display:flex;
    gap:16px;
    flex:1;
    justify-content:center;
}
.header-links a{
    color:var(--neon);
    text-decoration:none;
    font-weight:600;
}
.header-buttons a{
    padding:8px 16px;
    border:2px solid var(--neon);
    color:var(--neon);
    border-radius:6px;
    text-decoration:none;
    margin-left:8px;
}

/* PLAYER */
.player-shell{
    position:relative;
    width:100%;
    aspect-ratio:16/9;
    max-height:70vh;
    border-radius:22px;
    overflow:hidden;
    background:#000;
    box-shadow:0 0 35px rgba(0,255,213,.6),
               inset 0 0 30px rgba(0,255,213,.15);
}
.player-shell video{
    width:100%;
    height:100%;
    object-fit:cover;
}

/* CHANNEL GRID */
.channel-grid{
    display:grid;
    grid-template-columns:repeat(auto-fit,minmax(180px,1fr));
    gap:22px;
    margin:30px 0;
}
.channel-card{
    background:#020b10;
    border-radius:16px;
    padding:20px 14px;
    text-align:center;
    cursor:pointer;
    transition:.35s;
    border:1px solid rgba(255,255,255,.1);
}
.channel-card:hover,
.channel-card.active{
    transform:scale(1.05);
    box-shadow:0 0 35px rgba(0,255,213,.8);
}
.channel-card img{
    max-height:60px;
    max-width:140px;
    margin-bottom:12px;
}

/* FOOTER */
.site-footer{
    background:#020b10;
    padding:40px 20px;
    text-align:center;
}
.footer-social a{
    display:inline-block;
    width:34px;
    height:34px;
    margin:0 8px;
}
.footer-social svg{
    width:100%;
    height:100%;
    fill:#fff;
    transition:.3s;
}
.footer-social a:hover svg{
    fill:var(--accent);
}
</style>
</head>

<body oncontextmenu="return false;">

<!-- HEADER -->
<header class="site-header">
    <div class="site-branding">
        <a href="https://jisanhsajin.free.nf/">
            <img src="https://jisanhsajin.free.nf/wp-content/uploads/2025/11/cropped-Untitled-design-1-89x89.png">
            <span>Md Jisan Hossain Sajin</span>
        </a>
    </div>
    <div class="header-links">
        <a href="#channels">Channels</a>
        <a href="#footer">Connect</a>
    </div>
    <div class="header-buttons">
        <a href="https://jisanhsajin.page.gd/">Jisan</a>
        <a href="https://jisanhsajin.free.nf/">Software</a>
    </div>
</header>

<div class="container mt-4">

<!-- PLAYER -->
<div class="player-shell mb-4">
    <video id="video" controls muted playsinline preload="auto"></video>
</div>

<!-- CHANNELS -->
<div class="channel-grid" id="channels">
<?php foreach ($channels as $ch): ?>
    <div class="channel-card"
         onclick="play(this,'<?= htmlspecialchars($ch['url']) ?>')">
        <img src="<?= htmlspecialchars($ch['logo']) ?>">
        <span><?= htmlspecialchars($ch['name']) ?></span>
    </div>
<?php endforeach; ?>
</div>

</div>

<!-- FOOTER -->
<footer class="site-footer" id="footer">
    <div class="footer-social">
        <!-- Facebook -->
        <a href="https://www.facebook.com/jisanhsajin/" target="_blank">
            <svg viewBox="0 0 24 24"><path d="M22.675 0H1.325C.593 0 0 .593 0 1.325v21.351C0 23.407.593 24 1.325 24H12.82v-9.294H9.692v-3.622h3.128V8.413c0-3.1 1.894-4.788 4.659-4.788 1.325 0 2.464.099 2.796.143v3.24l-1.918.001c-1.504 0-1.795.715-1.795 1.763v2.312h3.587l-.467 3.622h-3.12V24h6.116c.73 0 1.324-.593 1.324-1.324V1.325C24 .593 23.407 0 22.675 0z"/></svg>
        </a>

        <!-- Instagram -->
        <a href="https://www.instagram.com/jisanhsajin/" target="_blank">
            <svg viewBox="0 0 24 24"><path d="M7 2h10a5 5 0 0 1 5 5v10a5 5 0 0 1-5 5H7a5 5 0 0 1-5-5V7a5 5 0 0 1 5-5zm5 5a5 5 0 1 0 0 10 5 5 0 0 0 0-10zm6.5-.9a1.1 1.1 0 1 0 0 2.2 1.1 1.1 0 0 0 0-2.2z"/></svg>
        </a>

        <!-- LinkedIn -->
        <a href="https://www.linkedin.com/in/jisanhsajin/" target="_blank">
            <svg viewBox="0 0 24 24"><path d="M20.447 20.452H17.24v-5.569c0-1.327-.026-3.037-1.85-3.037-1.852 0-2.136 1.447-2.136 2.942v5.664H9.06V9h3.033v1.561h.043c.423-.8 1.455-1.644 2.996-1.644 3.202 0 3.794 2.107 3.794 4.847v6.688zM5.337 7.433a1.755 1.755 0 1 1 0-3.509 1.755 1.755 0 0 1 0 3.509zM6.814 20.452H3.861V9h2.953v11.452z"/></svg>
        </a>

        <!-- YouTube -->
        <a href="https://www.youtube.com/@JisanHSajin" target="_blank">
            <svg viewBox="0 0 24 24"><path d="M23.498 6.186a2.946 2.946 0 0 0-2.074-2.075C19.708 3.5 12 3.5 12 3.5s-7.708 0-9.424.611A2.946 2.946 0 0 0 .502 6.186C0 7.895 0 12 0 12s0 4.105.502 5.814a2.946 2.946 0 0 0 2.074 2.075C4.292 20.5 12 20.5 12 20.5s7.708 0 9.424-.611a2.946 2.946 0 0 0 2.074-2.075C24 16.105 24 12 24 12s0-4.105-.502-5.814zM9.545 15.568V8.432L15.818 12z"/></svg>
        </a>

        <!-- GitHub -->
        <a href="https://github.com/jisanhsajin" target="_blank">
            <svg viewBox="0 0 24 24"><path d="M12 .297c-6.63 0-12 5.373-12 12 0 5.303 3.438 9.8 8.205 11.387.6.113.82-.258.82-.577v-2.234c-3.338.724-4.042-1.61-4.042-1.61-.546-1.387-1.333-1.756-1.333-1.756-1.089-.744.084-.729.084-.729 1.205.084 1.838 1.237 1.838 1.237 1.07 1.835 2.809 1.304 3.495.997.108-.776.418-1.304.762-1.604-2.665-.3-5.467-1.332-5.467-5.93 0-1.31.468-2.38 1.236-3.22-.124-.303-.536-1.523.116-3.176 0 0 1.008-.322 3.3 1.23.957-.266 1.983-.399 3.003-.404 1.02.005 2.047.138 3.006.404 2.29-1.552 3.296-1.23 3.296-1.23.653 1.653.242 2.873.118 3.176.77.84 1.236 1.91 1.236 3.22 0 4.61-2.807 5.625-5.479 5.921.43.372.823 1.102.823 2.222v3.293c0 .321.216.694.825.576C20.565 22.092 24 17.592 24 12.297c0-6.627-5.373-12-12-12z"/></svg>
        </a>
    </div>

    <p>© 2026 Md Jisan Hossain Sajin</p>
</footer>

<script>
let hls;
function play(card,url){
    const video=document.getElementById('video');
    document.querySelectorAll('.channel-card')
        .forEach(c=>c.classList.remove('active'));
    card.classList.add('active');

    if(hls){hls.destroy();hls=null;}

    if(Hls.isSupported()){
        hls=new Hls({lowLatencyMode:true});
        hls.loadSource(url);
        hls.attachMedia(video);
        hls.on(Hls.Events.MANIFEST_PARSED,()=>video.play());
    }else{
        video.src=url;
        video.play();
    }
}
</script>

</body>
</html>
